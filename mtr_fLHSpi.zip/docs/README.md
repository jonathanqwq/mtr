---
home: true
heroImage: https://1r2image.com/images/2022/07/17/Dmhf.png
actionText: 下载mod →
actionLink: /download/
features:
- title: 简洁至上
  details: 以 Markdown 为中心的项目结构，使界面简洁明了。
- title: 高速下载
  details: 提供MTRmod高速下载节点，不再因网络苦苦等待。
- title: 用爱发电
  details: 由BC413发起的完全免费的文档站及下载站，不含任何广告！
footer: MIT Licensed | Copyright © 2013 - 2022 BC413
---