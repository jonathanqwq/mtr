# 模组下载

::: tip
在您网络流畅时应前往[官方CurseForge](https://www.curseforge.com/minecraft/mc-mods/minecraft-transit-railway)或[Discord群组](https://discord.com/invite/PVZ2nfUaTW)下载，在一些情况下，我们可能没法提供最新的版本
:::

### 本体

